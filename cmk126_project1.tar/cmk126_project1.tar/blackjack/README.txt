Please compile on C99 mode.
